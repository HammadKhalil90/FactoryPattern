﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Pizza
{
    public class VegiePizzas : Pizzas
    {
        public override void Prepare()
        {
            throw new NotImplementedException();
        }

        public override void Bake()
        {
            throw new NotImplementedException();
        }

        public override void Cut()
        {
            throw new NotImplementedException();
        }

        public override void Box()
        {
            throw new NotImplementedException();
        }
    }

    public class PepperoniPizzas : Pizzas
    {
        public override void Prepare()
        {
            throw new NotImplementedException();
        }

        public override void Bake()
        {
            throw new NotImplementedException();
        }

        public override void Cut()
        {
            throw new NotImplementedException();
        }

        public override void Box()
        {
            throw new NotImplementedException();
        }
    }
    public class ClamPizzas : Pizzas
    {
        public override void Prepare()
        {
            throw new NotImplementedException();
        }

        public override void Bake()
        {
            throw new NotImplementedException();
        }

        public override void Cut()
        {
            throw new NotImplementedException();
        }

        public override void Box()
        {
            throw new NotImplementedException();
        }
    }

    public class CheesePizzas : Pizzas
    {
        public override void Prepare()
        {
            throw new NotImplementedException();
        }

        public override void Bake()
        {
            throw new NotImplementedException();
        }

        public override void Cut()
        {
            throw new NotImplementedException();
        }

        public override void Box()
        {
            throw new NotImplementedException();
        }
    }
    public abstract class Pizzas
    {
        public abstract void Prepare();

        public abstract void Bake();

        public abstract void Cut();

        public abstract void Box();
    }
}
