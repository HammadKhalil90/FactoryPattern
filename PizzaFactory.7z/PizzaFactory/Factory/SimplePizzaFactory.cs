﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Pizza;
namespace PizzaFactory
{
    public class SimplePizzaFactory
    {
        public Pizzas CreatePizza(string type)
        {
            Pizzas pizza = null;
            if (type.Equals("cheese"))
            {
                return new CheesePizzas();
            }
            if (type.Equals("pepperoni"))
            {
                return new PepperoniPizzas();
            }
            if (type.Equals("clam"))
            {
                return new ClamPizzas();
            }
            if (type.Equals("veggie"))
            {
                return new VegiePizzas();
            }
            return pizza;
        }

        
    }

   
}
